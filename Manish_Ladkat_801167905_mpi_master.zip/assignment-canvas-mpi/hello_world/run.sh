#!/bin/sh


source ../params.sh


mpirun ${MPI_PARAMS} ./hello
